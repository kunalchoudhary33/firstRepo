select * from dply_txt where txt_id = 2120929;
select * from dply_txt where txt_id = 2120919;